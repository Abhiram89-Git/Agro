import React from 'react';
import { Product } from '../../types';

interface ProductCardProps {
  product: Product;
  onAddToOrder?: (product: Product, quantity: number) => void;
}

export default function ProductCard({ product, onAddToOrder }: ProductCardProps) {
  const [quantity, setQuantity] = React.useState(1);

  const handleQuantityChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = parseInt(e.target.value);
    if (!isNaN(value) && value > 0) {
      setQuantity(value);
    }
  };

  return (
    <div className="border rounded-lg overflow-hidden shadow-md bg-white">
      <div className="h-48 bg-gray-200 flex items-center justify-center">
        {product.imageUrl ? (
          <img
            src={product.imageUrl}
            alt={product.name}
            className="w-full h-full object-cover"
          />
        ) : (
          <div className="text-gray-500">No image available</div>
        )}
      </div>
      <div className="p-4">
        <h3 className="text-lg font-semibold">{product.name}</h3>
        <p className="text-gray-600 mt-1">{product.description}</p>
        <div className="mt-2 flex justify-between items-center">
          <p className="text-green-600 font-semibold">
            ${product.price.toFixed(2)} / {product.unit}
          </p>
          <p className={`text-sm ${product.inStock ? 'text-green-600' : 'text-red-600'}`}>
            {product.inStock ? 'In Stock' : 'Out of Stock'}
          </p>
        </div>

        {onAddToOrder && product.inStock && (
          <div className="mt-4 flex items-center">
            <input
              type="number"
              min="1"
              value={quantity}
              onChange={handleQuantityChange}
              className="border rounded px-2 py-1 w-20 text-center"
            />
            <button
              onClick={() => onAddToOrder(product, quantity)}
              className="ml-2 bg-green-500 text-white py-1 px-4 rounded hover:bg-green-600 flex-grow"
            >
              Add to Order
            </button>
          </div>
        )}
      </div>
    </div>
  );
}