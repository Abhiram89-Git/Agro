import Link from 'next/link';
import React from 'react';

export default function Header() {
  return (
    <header className="bg-green-600 text-white shadow-md">
      <div className="container mx-auto px-4 py-4 flex justify-between items-center">
        <Link href="/" className="text-2xl font-bold">
          Agrofix
        </Link>
        <nav className="space-x-6">
          <Link href="/" className="hover:underline">
            Products
          </Link>
          <Link href="/orders/new" className="hover:underline">
            Place Order
          </Link>
          <Link href="/admin" className="hover:underline">
            Admin
          </Link>
        </nav>
      </div>
    </header>
  );
}