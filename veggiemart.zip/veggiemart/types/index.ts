export enum OrderStatus {
    PENDING = 'PENDING',
    IN_PROGRESS = 'IN_PROGRESS',
    DELIVERED = 'DELIVERED'
  }
  
  export interface Product {
    id: string;
    name: string;
    description: string;
    price: number;
    unit: string;
    inStock: boolean;
    imageUrl?: string;
    createdAt: string;
    updatedAt: string;
  }
  
  export interface OrderItem {
    productId: string;
    name: string;
    price: number;
    unit: string;
    quantity: number;
  }
  
  export interface Order {
    id: string;
    buyerName: string;
    buyerContact: string;
    deliveryAddress: string;
    items: OrderItem[];
    status: OrderStatus;
    totalAmount: number;
    createdAt: string;
    updatedAt: string;
  }