// pages/api/orders/index.ts
import { NextApiRequest, NextApiResponse } from 'next';
import prisma from '../../../lib/prisma';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  switch (req.method) {
    case 'GET':
      return getOrders(req, res);
    case 'POST':
      return createOrder(req, res);
    default:
      return res.status(405).json({ message: 'Method not allowed' });
  }
}

async function getOrders(req: NextApiRequest, res: NextApiResponse) {
  try {
    const orders = await prisma.order.findMany({
      orderBy: { createdAt: 'desc' },
    });
    return res.status(200).json(orders);
  } catch (error) {
    console.error('Error fetching orders:', error);
    return res.status(500).json({ message: 'Error fetching orders' });
  }
}

async function createOrder(req: NextApiRequest, res: NextApiResponse) {
  try {
    const { buyerName, buyerContact, deliveryAddress, items, totalAmount } = req.body;

    if (!buyerName || !buyerContact || !deliveryAddress || !items || !totalAmount) {
      return res.status(400).json({ message: 'Missing required fields' });
    }

    const order = await prisma.order.create({
      data: {
        buyerName,
        buyerContact,
        deliveryAddress,
        items,
        totalAmount: typeof totalAmount === 'string' ? parseFloat(totalAmount) : totalAmount,
      },
    });

    return res.status(201).json(order);
  } catch (error) {
    console.error('Error creating order:', error);
    return res.status(500).json({ message: 'Error creating order' });
  }
}