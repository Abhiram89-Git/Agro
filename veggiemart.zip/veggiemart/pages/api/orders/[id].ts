// pages/api/orders/[id].ts
import { NextApiRequest, NextApiResponse } from 'next';
import prisma from '../../../lib/prisma';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const { id } = req.query;
  
  if (!id || typeof id !== 'string') {
    return res.status(400).json({ message: 'Invalid order ID' });
  }

  switch (req.method) {
    case 'GET':
      return getOrderById(req, res, id);
    case 'PUT':
      return updateOrder(req, res, id);
    default:
      return res.status(405).json({ message: 'Method not allowed' });
  }
}

async function getOrderById(req: NextApiRequest, res: NextApiResponse, id: string) {
  try {
    const order = await prisma.order.findUnique({
      where: { id },
    });

    if (!order) {
      return res.status(404).json({ message: 'Order not found' });
    }

    return res.status(200).json(order);
  } catch (error) {
    console.error('Error fetching order:', error);
    return res.status(500).json({ message: 'Error fetching order' });
  }
}

async function updateOrder(req: NextApiRequest, res: NextApiResponse, id: string) {
  try {
    const { status } = req.body;

    if (!status) {
      return res.status(400).json({ message: 'Missing status field' });
    }

    const validStatuses = ['PENDING', 'IN_PROGRESS', 'DELIVERED'];
    if (!validStatuses.includes(status)) {
      return res.status(400).json({ message: 'Invalid status value' });
    }

    const order = await prisma.order.update({
      where: { id },
      data: { status },
    });

    return res.status(200).json(order);
  } catch (error) {
    console.error('Error updating order:', error);
    return res.status(500).json({ message: 'Error updating order' });
  }
}