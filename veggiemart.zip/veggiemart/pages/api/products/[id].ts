// pages/api/products/[id].ts
import { NextApiRequest, NextApiResponse } from 'next';
import prisma from '../../../lib/prisma';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const { id } = req.query;
  
  if (!id || typeof id !== 'string') {
    return res.status(400).json({ message: 'Invalid product ID' });
  }

  switch (req.method) {
    case 'GET':
      return getProductById(req, res, id);
    case 'PUT':
      return updateProduct(req, res, id);
    case 'DELETE':
      return deleteProduct(req, res, id);
    default:
      return res.status(405).json({ message: 'Method not allowed' });
  }
}

async function getProductById(req: NextApiRequest, res: NextApiResponse, id: string) {
  try {
    const product = await prisma.product.findUnique({
      where: { id },
    });

    if (!product) {
      return res.status(404).json({ message: 'Product not found' });
    }

    return res.status(200).json(product);
  } catch (error) {
    console.error('Error fetching product:', error);
    return res.status(500).json({ message: 'Error fetching product' });
  }
}

async function updateProduct(req: NextApiRequest, res: NextApiResponse, id: string) {
  try {
    const { name, description, price, unit, inStock, imageUrl } = req.body;

    if (!name || !description || !price || !unit) {
      return res.status(400).json({ message: 'Missing required fields' });
    }

    const product = await prisma.product.update({
      where: { id },
      data: {
        name,
        description,
        price: typeof price === 'string' ? parseFloat(price) : price,
        unit,
        inStock: typeof inStock === 'string' ? inStock === 'true' : inStock,
        imageUrl,
      },
    });

    return res.status(200).json(product);
  } catch (error) {
    console.error('Error updating product:', error);
    return res.status(500).json({ message: 'Error updating product' });
  }
}

async function deleteProduct(req: NextApiRequest, res: NextApiResponse, id: string) {
  try {
    await prisma.product.delete({
      where: { id },
    });

    return res.status(200).json({ message: 'Product deleted successfully' });
  } catch (error) {
    console.error('Error deleting product:', error);
    return res.status(500).json({ message: 'Error deleting product' });
  }
}