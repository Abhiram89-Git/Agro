// pages/api/products/index.ts
import { NextApiRequest, NextApiResponse } from 'next';
import prisma from '../../../lib/prisma';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  switch (req.method) {
    case 'GET':
      return getProducts(req, res);
    case 'POST':
      return createProduct(req, res);
    default:
      return res.status(405).json({ message: 'Method not allowed' });
  }
}

async function getProducts(req: NextApiRequest, res: NextApiResponse) {
  try {
    const products = await prisma.product.findMany({
      orderBy: { name: 'asc' },
    });
    return res.status(200).json(products);
  } catch (error) {
    console.error('Error fetching products:', error);
    return res.status(500).json({ message: 'Error fetching products' });
  }
}

async function createProduct(req: NextApiRequest, res: NextApiResponse) {
  try {
    const { name, description, price, unit, inStock, imageUrl } = req.body;

    if (!name || !description || !price || !unit) {
      return res.status(400).json({ message: 'Missing required fields' });
    }

    const product = await prisma.product.create({
      data: {
        name,
        description,
        price: typeof price === 'string' ? parseFloat(price) : price,
        unit,
        inStock: typeof inStock === 'string' ? inStock === 'true' : inStock,
        imageUrl,
      },
    });

    return res.status(201).json(product);
  } catch (error) {
    console.error('Error creating product:', error);
    return res.status(500).json({ message: 'Error creating product' });
  }
}