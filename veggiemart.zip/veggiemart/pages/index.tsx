import { useEffect, useState } from 'react';
import Head from 'next/head';
import Layout from '../components/layout/Layout';
import ProductList from '../components/products/ProductList';
import { Product } from '../types';

export default function Home() {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const response = await fetch('/api/products');
        if (!response.ok) {
          throw new Error('Failed to fetch products');
        }
        const data = await response.json();
        setProducts(data);
      } catch (error) {
        setError(error instanceof Error ? error.message : 'An error occurred');
      } finally {
        setLoading(false);
      }
    };

    fetchProducts();
  }, []);

  return (
    <Layout>
      <Head>
        <title>Agrofix - Bulk Produce Orders</title>
        <meta name="description" content="Order fresh vegetables and fruits in bulk" />
      </Head>

      <div className="mb-8">
        <h1 className="text-3xl font-bold">Fresh Produce Catalogue</h1>
        <p className="text-gray-600 mt-2">Browse our selection of fresh vegetables and fruits available for bulk orders</p>
      </div>

      {loading ? (
        <div className="flex justify-center items-center h-64">
          <p className="text-lg text-gray-600">Loading products...</p>
        </div>
      ) : error ? (
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded">
          {error}
        </div>
      ) : (
        <>
          {products.length > 0 ? (
            <ProductList products={products} />
          ) : (
            <div className="text-center py-12">
              <p className="text-gray-600">No products available at the moment.</p>
            </div>
          )}
        </>
      )}
    </Layout>
  );
}