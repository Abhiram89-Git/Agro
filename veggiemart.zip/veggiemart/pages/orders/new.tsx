import { useEffect, useState } from 'react';
import Head from 'next/head';
import Layout from '../../components/layout/Layout';
import OrderForm from '../../components/orders/OrderForm';
import ProductList from '../../components/products/ProductList';
import { Product, OrderItem } from '../../types';

export default function NewOrder() {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [orderItems, setOrderItems] = useState<OrderItem[]>([]);

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const response = await fetch('/api/products');
        if (!response.ok) {
          throw new Error('Failed to fetch products');
        }
        const data = await response.json();
        setProducts(data);
      } catch (error) {
        setError(error instanceof Error ? error.message : 'An error occurred');
      } finally {
        setLoading(false);
      }
    };

    fetchProducts();
  }, []);

  const addToOrder = (product: Product, quantity: number) => {
    // Check if product already exists in order
    const existingItemIndex = orderItems.findIndex(
      (item) => item.productId === product.id
    );

    if (existingItemIndex >= 0) {
      // Update quantity if product already in order
      const updatedItems = [...orderItems];
      updatedItems[existingItemIndex].quantity += quantity;
      setOrderItems(updatedItems);
    } else {
      // Add new item to order
      setOrderItems([
        ...orderItems,
        {
          productId: product.id,
          name: product.name,
          price: product.price,
          unit: product.unit,
          quantity,
        },
      ]);
    }
  };

  return (
    <Layout>
      <Head>
        <title>Place an Order - Agrofix</title>
        <meta name="description" content="Place your bulk produce order" />
      </Head>

      <div className="mb-8">
        <h1 className="text-3xl font-bold">Place an Order</h1>
        <p className="text-gray-600 mt-2">Select products and quantities for your bulk order</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          {loading ? (
            <div className="flex justify-center items-center h-64">
              <p className="text-lg text-gray-600">Loading products...</p>
            </div>
          ) : error ? (
            <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded">
              {error}
            </div>
          ) : (
            <>
              <h2 className="text-xl font-semibold mb-4">Available Products</h2>
              {products.length > 0 ? (
                <ProductList 
                  products={products} 
                  onAddToOrder={addToOrder} 
                />
              ) : (
                <div className="text-center py-12">
                  <p className="text-gray-600">No products available at the moment.</p>
                </div>
              )}
            </>
          )}
        </div>
        <div>
          <OrderForm products={products} />
        </div>
      </div>
    </Layout>
  );
}