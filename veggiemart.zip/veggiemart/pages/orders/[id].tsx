import { useRouter } from 'next/router';
import { useEffect, useState } from 'react';
import Head from 'next/head';
import Layout from '../../components/layout/Layout';
import OrderDetails from '../../components/orders/OrderDetails';
import { Order, OrderStatus } from '../../types';

export default function OrderDetailsPage() {
  const router = useRouter();
  const { id } = router.query;

  const [order, setOrder] = useState<Order | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchOrder = async () => {
      if (!id) return;

      try {
        setLoading(true);
        const response = await fetch(`/api/orders/${id}`);
        if (!response.ok) {
          throw new Error('Failed to fetch order details');
        }
        const data = await response.json();
        setOrder(data);
      } catch (error) {
        setError(error instanceof Error ? error.message : 'An error occurred');
      } finally {
        setLoading(false);
      }
    };

    fetchOrder();
  }, [id]);

  const handleStatusUpdate = async (status: OrderStatus) => {
    if (!order) return;

    try {
      const response = await fetch(`/api/orders/${order.id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ status }),
      });

      if (!response.ok) {
        throw new Error('Failed to update order status');
      }

      const updatedOrder = await response.json();
      setOrder(updatedOrder);
    } catch (error) {
      setError(error instanceof Error ? error.message : 'An error occurred');
    }
  };

  return (
    <Layout>
      <Head>
        <title>{order ? `Order #${order.id.substring(0, 8)}` : 'Order Details'} - Agrofix</title>
        <meta name="description" content="Order details" />
      </Head>

      <div className="mb-8">
        <button
          onClick={() => router.back()}
          className="text-blue-600 hover:underline flex items-center"
        >
          ← Back
        </button>
      </div>

      {loading ? (
        <div className="flex justify-center items-center h-64">
          <p className="text-lg text-gray-600">Loading order details...</p>
        </div>
      ) : error ? (
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded">
          {error}
        </div>
      ) : order ? (
        <OrderDetails 
          order={order} 
          isAdmin={true} 
          onStatusUpdate={handleStatusUpdate} 
        />
      ) : (
        <div className="text-center py-12">
          <p className="text-gray-600">Order not found.</p>
        </div>
      )}
    </Layout>
  );
}