// pages/admin/orders.tsx
import { useState, useEffect } from 'react';
import Layout from '../../components/layout/Layout';
import OrdersTable from '../../components/admin/OrdersTable';
import { Order } from '../../types';

export default function AdminOrders() {
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<string>('ALL');

  useEffect(() => {
    fetchOrders();
  }, []);

  async function fetchOrders() {
    try {
      setLoading(true);
      const res = await fetch('/api/orders');
      if (!res.ok) throw new Error('Failed to fetch orders');
      const data = await res.json();
      setOrders(data);
    } catch (error) {
      console.error('Error fetching orders:', error);
    } finally {
      setLoading(false);
    }
  }

  async function handleUpdateOrderStatus(orderId: string, newStatus: string) {
    try {
      const res = await fetch(`/api/orders/${orderId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: newStatus }),
      });
      
      if (!res.ok) throw new Error('Failed to update order status');
      
      // Update local state to avoid refetching
      setOrders(orders.map(order => 
        order.id === orderId ? { ...order, status: newStatus } : order
      ));
    } catch (error) {
      console.error('Error updating order status:', error);
    }
  }

  const filteredOrders = filter === 'ALL' 
    ? orders 
    : orders.filter(order => order.status === filter);

  return (
    <Layout>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-8">Manage Orders</h1>
        
        <div className="mb-6">
          <div className="sm:flex sm:justify-between sm:items-center">
            <div className="flex space-x-4">
              <button
                onClick={() => setFilter('ALL')}
                className={`px-3 py-2 text-sm font-medium rounded-md ${
                  filter === 'ALL'
                    ? 'bg-green-100 text-green-800'
                    : 'text-gray-500 hover:text-gray-700'
                }`}
              >
                All Orders
              </button>
              <button
                onClick={() => setFilter('PENDING')}
                className={`px-3 py-2 text-sm font-medium rounded-md ${
                  filter === 'PENDING'
                    ? 'bg-yellow-100 text-yellow-800'
                    : 'text-gray-500 hover:text-gray-700'
                }`}
              >
                Pending
              </button>
              <button
                onClick={() => setFilter('IN_PROGRESS')}
                className={`px-3 py-2 text-sm font-medium rounded-md ${
                  filter === 'IN_PROGRESS'
                    ? 'bg-blue-100 text-blue-800'
                    : 'text-gray-500 hover:text-gray-700'
                }`}
              >
                In Progress
              </button>
              <button
                onClick={() => setFilter('DELIVERED')}
                className={`px-3 py-2 text-sm font-medium rounded-md ${
                  filter === 'DELIVERED'
                    ? 'bg-green-100 text-green-800'
                    : 'text-gray-500 hover:text-gray-700'
                }`}
              >
                Delivered
              </button>
            </div>
            <div className="mt-4 sm:mt-0">
              <button
                onClick={fetchOrders}
                className="inline-flex items-center px-4 py-2 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500"
              >
                Refresh Orders
              </button>
            </div>
          </div>
        </div>

        {loading ? (
          <div className="flex justify-center items-center h-64">
            <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-green-500"></div>
          </div>
        ) : (
          <OrdersTable 
            orders={filteredOrders} 
            onUpdateStatus={handleUpdateOrderStatus} 
          />
        )}
      </div>
    </Layout>
  );
}